
Demo code for FPC1020 fingerprint sensor.
Author: Deray
Data: 2015/10/07

Documents:

http://deegou.com/hardware/fpc1020/
